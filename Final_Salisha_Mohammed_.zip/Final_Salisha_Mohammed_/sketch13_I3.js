
let video;
let pose;
let nose;

function preload() {
   // sound = loadSound("images/piano.mp3");
   // bells = loadSound("images/bells.mp3");
    nose = loadImage("images/splash.png");
    



}
function setup() {
    createCanvas(800, 480);
    video = createCapture(VIDEO);

    video.size(width, height);
    poseNet = ml5.poseNet(video, modelLoaded);
    poseNet.on('pose', gotPoses)
    video.hide();
}

function modelLoaded() {
    console.log("modelLoaded function has been called so this work!!!!");
};

function gotPoses(poses) {
    console.log(poses);
    if (poses.length > 0) {
        pose = poses[0].pose;
    }

}

function draw() {

    translate(width, 0);
    scale(-1, 1);
    image(video, 0, 0, width, height);
    //filter(INVERT);
    filter(POSTERIZE, 3);
    if (pose) {

        //ellipse(pose.leftEye.x, pose.leftEye.y, 10);
        tint(255, 155);
        stroke(255, 255, 255);
        strokeWeight(5);
        fill('rgba(0,255,255, 0.1)');
        rect(0, 0, width / 5, height);
        fill('rgba(255,0,255, 0.1)');
        rect((width / 5), 0, (width / 5), height);
        fill('rgba(0,255,0, 0.1)');
        rect((width / 5) * 2, 0, (width / 5), height);
        fill('rgba(255,0,255, 0.1)');
        rect((width / 5) * 3, 0, (width / 5), height);
        fill('rgba(0,255,255, 0.1)');
        rect((width / 5) * 4, 0, (width / 5), height);

        push();
        imageMode(CENTER);//didnt know how to perfectly align to the ear 

        image(nose, pose.leftWrist.x, pose.leftWrist.y, width / 10, height / 10);
        //scale(-1,1);
        //image(ear2,pose.rightEar.x, pose.rightEar.y,width/10,height/10);

        pop();
        //ellipse(pose.rightEye.x, pose.rightEye.y, 10);
        if (pose.leftWrist.x > 0 && pose.leftWrist.x < width / 5 && pose.leftWrist.y > 0 && pose.leftWrist.y < height) {
            fill(255, 255, 255);
            ellipse(20, 20, 40, 40);
            

        }
        else if (pose.leftWrist.x > width / 5 && pose.leftWrist.x < (width / 5) * 2 && pose.leftWrist.y > 0 && pose.leftWrist.y < height) {
            fill(255, 0, 255);
            ellipse(20, 20, 40, 40);
           
        }
        else if (pose.leftWrist.x > width / 5 * 2 && pose.leftWrist.x < (width / 5) * 3 && pose.leftWrist.y > 0 && pose.leftWrist.y < height) {
            fill(255, 255, 0);
            ellipse(20, 20, 40, 40);
            

        }
        else if (pose.leftWrist.x > width / 5 * 3 && pose.leftWrist.x < (width / 5) * 4 && pose.leftWrist.y > 0 && pose.leftWrist.y < height) {
            fill(0, 255, 155);
            ellipse(20, 20, 40, 40);
            
        }

        else if (pose.leftWrist.x > width / 5 * 4 && pose.leftWrist.x < (width / 5) * 5 && pose.leftWrist.y > 0 && pose.leftWrist.y < height) {
            fill(255, 0, 255);
            ellipse(20, 20, 40, 40);
            
        }
        else {

            
        }


    }
    fill(255, 255, 255);
}

function mousePressed(){
    //background(0);
    clear();
    image(video, 0, 0, width, height);
}